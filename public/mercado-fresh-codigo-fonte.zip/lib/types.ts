export type View = 'lists' | 'gas' | 'pantry' | 'offers' | 'games' | 'history' | 'settings' | 'detail';

export interface Currency {
  symbol: string;
  name: string;
  code: string;
}

export interface ThemeColor {
  id: string;
  name: string;
  hex: string;
  bg: string;
  text: string;
  border: string;
  light: string;
  hover: string;
  ring: string;
}

export interface GasCylinder {
  id: string;
  userId?: string;
  purchaseDate: string; // YYYY-MM-DD
  startDate: string; // YYYY-MM-DD
  endDate?: string | null; // YYYY-MM-DD or null if currently in use
  price: number;
  brand?: string;
  notes?: string;
  status: 'in_use' | 'finished';
  createdAt?: number;
  updatedAt?: number;
}

export interface ListItem {
  id: string;
  name: string;
  category: string;
  price: number;
  quantity: number;
  checked: boolean;
  unit?: string;
  weight?: string;
  notes?: string;
  offer?: boolean;
  bulkDiscount?: string;
  wholesalePrice?: number;
  minWholesaleQty?: number;
  importanceLevel?: number; // 0: None, 1: Star 1 (amber), 2: Star 2 (blue), 3: Star 3 (orange)
}

export interface GroceryList {
  id: string;
  name: string;
  status: 'Em andamento' | 'Concluído';
  icon: string;
  color: string;
  items: ListItem[];
  avatars?: string[];
  extra?: number;
  budgetLimit: number;
  completedAt?: string;
  totalAmount?: number;
  userId?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface PantryItem {
  id: string;
  name: string;
  brand: string;
  quantity: number;
  unit: string;
  category: string;
  expiryDate?: string;
  minQuantity: number;
  restockBuyQuantity: number;
  reminderEnabled: boolean;
  alertDismissedForMinQty?: boolean;
  createdAt?: number;
  updatedAt?: number;
}
