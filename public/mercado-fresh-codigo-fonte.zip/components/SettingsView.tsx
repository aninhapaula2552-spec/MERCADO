'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Scale, 
  Palette, 
  Check, 
  RotateCcw, 
  MessageSquarePlus, 
  ShoppingBasket, 
  ChevronRight 
} from 'lucide-react';
import { Currency, ThemeColor } from '../lib/types';
import { CURRENCIES, THEME_COLORS } from '../lib/constants';

interface SettingsViewProps {
  currency: Currency;
  onCurrencyChange: (c: Currency) => void;
  themeColor: ThemeColor;
  onThemeChange: (t: ThemeColor) => void;
  suggestions: string;
  onSuggestionsChange: (s: string) => void;
  onResetData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  currency,
  onCurrencyChange,
  themeColor,
  onThemeChange,
  suggestions,
  onSuggestionsChange,
  onResetData
}) => {
  const [isCurrencyOpen, setIsCurrencyOpen] = useState(false);
  const [isThemeOpen, setIsThemeOpen] = useState(false);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="pt-20 px-4 max-w-2xl mx-auto pb-32"
    >
      <header className="mb-6">
        <h2 className="text-2xl font-black text-slate-900 mb-1">Ajustes & Preferências</h2>
        <p className="text-xs text-slate-400">Configure moedas, cores e dados do seu app</p>
      </header>

      <div className="space-y-3.5">
        {/* Storage Card */}
        <div className="bg-white rounded-3xl p-5 shadow-xs border border-slate-200/70 flex items-center gap-4">
          <div className={`w-12 h-12 rounded-2xl ${themeColor.light} ${themeColor.text} flex items-center justify-center shrink-0`}>
            <ShoppingBasket size={24} />
          </div>
          <div>
            <h3 className="text-sm font-black text-slate-900 leading-tight">Armazenamento 100% Local</h3>
            <p className="text-xs text-slate-400 mt-0.5">Seus dados ficam guardados neste dispositivo com total privacidade</p>
            <span className="inline-flex items-center gap-1 mt-1.5 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
              <Check size={11} /> Pronto para uso offline
            </span>
          </div>
        </div>

        {/* Currency Selector Card */}
        <div 
          onClick={() => setIsCurrencyOpen(true)}
          className="bg-white rounded-3xl p-5 shadow-xs border border-slate-200/70 flex items-center justify-between cursor-pointer hover:shadow-xs transition-all active:scale-99"
        >
          <div className="flex items-center gap-4">
            <div className={`w-11 h-11 rounded-2xl ${themeColor.light} ${themeColor.text} flex items-center justify-center shrink-0`}>
              <Scale size={20} />
            </div>
            <div>
              <p className="text-sm font-bold text-slate-900">Moeda Principal</p>
              <p className="text-xs text-slate-400">{currency.name} ({currency.code})</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className={`text-base font-black ${themeColor.text}`}>{currency.symbol}</span>
            <ChevronRight size={18} className="text-slate-300" />
          </div>
        </div>

        {/* Theme Selector Card */}
        <div 
          onClick={() => setIsThemeOpen(true)}
          className="bg-white rounded-3xl p-5 shadow-xs border border-slate-200/70 flex items-center justify-between cursor-pointer hover:shadow-xs transition-all active:scale-99"
        >
          <div className="flex items-center gap-4">
            <div className={`w-11 h-11 rounded-2xl ${themeColor.light} ${themeColor.text} flex items-center justify-center shrink-0`}>
              <Palette size={20} />
            </div>
            <div>
              <p className="text-sm font-bold text-slate-900">Cor do Aplicativo</p>
              <p className="text-xs text-slate-400">Tema {themeColor.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-6 h-6 rounded-full ${themeColor.bg} border-2 border-white shadow-xs`} />
            <ChevronRight size={18} className="text-slate-300" />
          </div>
        </div>

        {/* Suggestions Box */}
        <div className="bg-white rounded-3xl p-5 shadow-xs border border-slate-200/70">
          <div className="flex items-center gap-3 mb-2.5">
            <div className={`w-9 h-9 rounded-xl ${themeColor.light} ${themeColor.text} flex items-center justify-center`}>
              <MessageSquarePlus size={18} />
            </div>
            <div>
              <p className="text-sm font-bold text-slate-900">Anotações & Sugestões</p>
              <p className="text-xs text-slate-400">Ideias ou lembretes pessoais para compras</p>
            </div>
          </div>
          <textarea
            value={suggestions}
            onChange={(e) => onSuggestionsChange(e.target.value)}
            placeholder="Escreva anotações ou melhorias desejadas..."
            className={`w-full h-24 p-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-medium text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 ${themeColor.ring} resize-none`}
          />
        </div>

        {/* Reset Default Data */}
        <div className="bg-white rounded-3xl p-5 shadow-xs border border-slate-200/70">
          <h3 className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-2">Manutenção de Dados</h3>
          <button
            onClick={() => setIsResetConfirmOpen(true)}
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold text-xs transition-colors active:scale-98"
          >
            <div className="flex items-center gap-2.5">
              <RotateCcw size={16} />
              <span>Restaurar Dados Padrão de Exemplo</span>
            </div>
            <ChevronRight size={16} className="text-amber-400" />
          </button>
        </div>
      </div>

      {/* Currency Modal */}
      <AnimatePresence>
        {isCurrencyOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl border border-slate-100"
            >
              <h3 className="text-lg font-extrabold text-slate-900 mb-4">Escolher Moeda</h3>
              <div className="space-y-2">
                {CURRENCIES.map((c) => (
                  <button
                    key={c.code}
                    onClick={() => {
                      onCurrencyChange(c);
                      setIsCurrencyOpen(false);
                    }}
                    className={`w-full p-3.5 rounded-2xl flex items-center justify-between border text-left transition-all ${
                      currency.code === c.code 
                        ? `${themeColor.light} ${themeColor.border} border-2` 
                        : 'border-slate-200/80 hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <p className="text-sm font-bold text-slate-900">{c.name}</p>
                      <p className="text-xs text-slate-400">{c.code}</p>
                    </div>
                    <span className={`text-base font-black ${themeColor.text}`}>{c.symbol}</span>
                  </button>
                ))}
              </div>
              <button 
                onClick={() => setIsCurrencyOpen(false)}
                className="w-full mt-4 h-11 rounded-2xl bg-slate-100 text-slate-600 font-bold text-xs"
              >
                Fechar
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Theme Modal */}
      <AnimatePresence>
        {isThemeOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl border border-slate-100"
            >
              <h3 className="text-lg font-extrabold text-slate-900 mb-4">Cor do Aplicativo</h3>
              <div className="space-y-2">
                {THEME_COLORS.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => {
                      onThemeChange(t);
                      setIsThemeOpen(false);
                    }}
                    className={`w-full p-3.5 rounded-2xl flex items-center justify-between border text-left transition-all ${
                      themeColor.id === t.id 
                        ? `${t.light} ${t.border} border-2` 
                        : 'border-slate-200/80 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-7 h-7 rounded-full ${t.bg} border-2 border-white shadow-xs`} />
                      <span className="text-sm font-bold text-slate-900">{t.name}</span>
                    </div>
                    {themeColor.id === t.id && <Check className={t.text} size={18} strokeWidth={3} />}
                  </button>
                ))}
              </div>
              <button 
                onClick={() => setIsThemeOpen(false)}
                className="w-full mt-4 h-11 rounded-2xl bg-slate-100 text-slate-600 font-bold text-xs"
              >
                Fechar
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Reset Confirmation Modal */}
      <AnimatePresence>
        {isResetConfirmOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl border border-slate-100"
            >
              <h3 className="text-lg font-extrabold text-slate-900 mb-2">Restaurar Dados?</h3>
              <p className="text-xs text-slate-500 mb-5 leading-relaxed">
                Todas as listas e itens atuais serão substituídos pelos dados de exemplo padrão.
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => setIsResetConfirmOpen(false)}
                  className="flex-1 h-11 rounded-2xl bg-slate-100 text-slate-600 font-bold text-xs"
                >
                  Cancelar
                </button>
                <button
                  onClick={() => {
                    onResetData();
                    setIsResetConfirmOpen(false);
                  }}
                  className="flex-1 h-11 rounded-2xl bg-rose-600 text-white font-bold text-xs shadow-xs hover:bg-rose-700 transition-colors"
                >
                  Restaurar
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
