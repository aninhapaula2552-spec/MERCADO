'use client';

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Home, 
  Plus, 
  Minus, 
  Package, 
  Search, 
  Trash2, 
  Edit3, 
  Sparkles, 
  ShoppingCart,
  AlertTriangle
} from 'lucide-react';
import { PantryItem, GroceryList, ThemeColor } from '../lib/types';
import { PANTRY_CATEGORIES, PANTRY_UNITS } from '../lib/constants';
import { safeNumber, generateId } from '../lib/utils';

interface PantryViewProps {
  items: PantryItem[];
  onUpdateItems: (items: PantryItem[]) => void;
  lists: GroceryList[];
  onAddToList: (listId: string, item: { name: string; category: string; quantity: number; unit?: string; notes?: string }) => void;
  onNavigateToList: (listId: string) => void;
  themeColor: ThemeColor;
}

export const PantryView: React.FC<PantryViewProps> = ({
  items,
  onUpdateItems,
  lists,
  onAddToList,
  onNavigateToList,
  themeColor
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todas');
  const [activeFilter, setActiveFilter] = useState<'all' | 'critical' | 'warning' | 'ok'>('all');

  // Form State (Add / Edit)
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<PantryItem | null>(null);
  const [formName, setFormName] = useState('');
  const [formBrand, setFormBrand] = useState('');
  const [formQuantity, setFormQuantity] = useState('1');
  const [formUnit, setFormUnit] = useState('pacotes');
  const [formCategory, setFormCategory] = useState('Alimentos');
  const [formExpiryDate, setFormExpiryDate] = useState('');
  const [formMinQuantity, setFormMinQuantity] = useState('1');
  const [formRestockBuyQuantity, setFormRestockBuyQuantity] = useState('2');

  // Replenishment Alert Modal
  const [alertProduct, setAlertProduct] = useState<PantryItem | null>(null);
  const [selectedListIdForAlert, setSelectedListIdForAlert] = useState<string>('');
  const [alertBuyQuantity, setAlertBuyQuantity] = useState<number>(2);

  // In-app Notification Toast
  const [toastMessage, setToastMessage] = useState<{ text: string; listId?: string } | null>(null);

  const showToast = (text: string, listId?: string) => {
    setToastMessage({ text, listId });
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Stock Decrement
  const handleDecrementStock = (item: PantryItem) => {
    if (item.quantity <= 0) return;
    const newQty = item.quantity - 1;
    const shouldAlert = newQty <= item.minQuantity && !item.alertDismissedForMinQty;

    const updated = items.map(p => p.id === item.id ? { ...p, quantity: newQty, updatedAt: Date.now() } : p);
    onUpdateItems(updated);

    if (shouldAlert) {
      setAlertProduct({ ...item, quantity: newQty });
      setAlertBuyQuantity(item.restockBuyQuantity || (item.minQuantity * 2 || 2));
      if (lists.length > 0) {
        const active = lists.find(l => l.status === 'Em andamento') || lists[0];
        setSelectedListIdForAlert(active.id);
      }
    }
  };

  // Stock Increment
  const handleIncrementStock = (item: PantryItem) => {
    const newQty = item.quantity + 1;
    const cycleReset = newQty > item.minQuantity;

    const updated = items.map(p => p.id === item.id ? {
      ...p,
      quantity: newQty,
      alertDismissedForMinQty: cycleReset ? false : p.alertDismissedForMinQty,
      updatedAt: Date.now()
    } : p);
    onUpdateItems(updated);
  };

  // Confirm Replenishment to Grocery List
  const handleConfirmAddToList = () => {
    if (!alertProduct) return;
    let targetListId = selectedListIdForAlert;
    if (!targetListId && lists.length > 0) {
      targetListId = lists[0].id;
    }

    const itemNameToAdd = `${alertProduct.name}${alertProduct.brand ? ` ${alertProduct.brand}` : ''}`.trim();
    onAddToList(targetListId, {
      name: itemNameToAdd,
      category: alertProduct.category || 'Despensa',
      quantity: alertBuyQuantity > 0 ? alertBuyQuantity : 1,
      unit: alertProduct.unit,
      notes: `Reposição da despensa (estoque atual: ${alertProduct.quantity} ${alertProduct.unit})`
    });

    // Mark alert dismissed for this cycle
    const updated = items.map(p => p.id === alertProduct.id ? { ...p, alertDismissedForMinQty: true, updatedAt: Date.now() } : p);
    onUpdateItems(updated);

    showToast(`🛒 ${itemNameToAdd} adicionado à Lista!`, targetListId);
    setAlertProduct(null);
  };

  const handleOpenAdd = () => {
    setEditingItem(null);
    setFormName('');
    setFormBrand('');
    setFormQuantity('1');
    setFormUnit('pacotes');
    setFormCategory('Alimentos');
    setFormExpiryDate('');
    setFormMinQuantity('1');
    setFormRestockBuyQuantity('2');
    setIsFormOpen(true);
  };

  const handleOpenEdit = (item: PantryItem) => {
    setEditingItem(item);
    setFormName(item.name || '');
    setFormBrand(item.brand || '');
    setFormQuantity((item.quantity ?? 1).toString());
    setFormUnit(item.unit || 'pacotes');
    setFormCategory(item.category || 'Alimentos');
    setFormExpiryDate(item.expiryDate || '');
    setFormMinQuantity((item.minQuantity ?? 1).toString());
    setFormRestockBuyQuantity((item.restockBuyQuantity ?? 2).toString());
    setIsFormOpen(true);
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;

    const parsedQty = Math.max(0, safeNumber(formQuantity, 1));
    const parsedMin = Math.max(0, safeNumber(formMinQuantity, 1));
    const parsedRestock = Math.max(1, safeNumber(formRestockBuyQuantity, 2));

    if (editingItem) {
      const updated = items.map(p => p.id === editingItem.id ? {
        ...p,
        name: formName.trim(),
        brand: formBrand.trim(),
        quantity: parsedQty,
        unit: formUnit,
        category: formCategory,
        expiryDate: formExpiryDate || undefined,
        minQuantity: parsedMin,
        restockBuyQuantity: parsedRestock,
        updatedAt: Date.now()
      } : p);
      onUpdateItems(updated);
    } else {
      const newItem: PantryItem = {
        id: generateId('pantry'),
        name: formName.trim(),
        brand: formBrand.trim(),
        quantity: parsedQty,
        unit: formUnit,
        category: formCategory,
        expiryDate: formExpiryDate || undefined,
        minQuantity: parsedMin,
        restockBuyQuantity: parsedRestock,
        reminderEnabled: true,
        alertDismissedForMinQty: false,
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      onUpdateItems([newItem, ...items]);
    }

    setIsFormOpen(false);
  };

  const handleDeleteItem = (id: string) => {
    onUpdateItems(items.filter(p => p.id !== id));
  };

  // Metrics
  const criticalCount = useMemo(() => items.filter(i => i && (i.quantity ?? 0) <= (i.minQuantity ?? 1)).length, [items]);
  const warningCount = useMemo(() => items.filter(i => i && (i.quantity ?? 0) === (i.minQuantity ?? 1) + 1).length, [items]);
  const okCount = useMemo(() => items.filter(i => i && (i.quantity ?? 0) > (i.minQuantity ?? 1) + 1).length, [items]);

  // Filtered Items
  const filteredItems = useMemo(() => {
    return items.filter(item => {
      if (!item) return false;
      const term = (searchTerm || '').toLowerCase();
      const matchName = (item.name || '').toLowerCase().includes(term);
      const matchBrand = (item.brand || '').toLowerCase().includes(term);
      const matchesSearch = matchName || matchBrand;

      const matchesCat = selectedCategory === 'Todas' || item.category === selectedCategory;

      let matchesFilter = true;
      if (activeFilter === 'critical') matchesFilter = (item.quantity ?? 0) <= (item.minQuantity ?? 1);
      if (activeFilter === 'warning') matchesFilter = (item.quantity ?? 0) === (item.minQuantity ?? 1) + 1;
      if (activeFilter === 'ok') matchesFilter = (item.quantity ?? 0) > (item.minQuantity ?? 1) + 1;

      return matchesSearch && matchesCat && matchesFilter;
    });
  }, [items, searchTerm, selectedCategory, activeFilter]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="pt-20 px-4 max-w-2xl mx-auto pb-32"
    >
      {/* Toast Alert */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -15, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -15, scale: 0.95 }}
            className="fixed top-18 left-4 right-4 max-w-md mx-auto z-50 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-xl flex items-center justify-between gap-3 text-xs"
          >
            <div className="flex items-center gap-2">
              <Sparkles size={16} className="text-amber-400 shrink-0" />
              <span>{toastMessage.text}</span>
            </div>
            {toastMessage.listId && (
              <button
                onClick={() => {
                  onNavigateToList(toastMessage.listId!);
                  setToastMessage(null);
                }}
                className="font-bold text-emerald-400 hover:underline shrink-0"
              >
                Ver Lista →
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Banner */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white p-5 rounded-3xl shadow-sm mb-4">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
            <Home size={15} /> Despensa Inteligente
          </div>
          <span className="text-[11px] bg-white/10 px-2.5 py-0.5 rounded-full font-semibold">
            {items.length} {items.length === 1 ? 'produto' : 'produtos'}
          </span>
        </div>
        <h2 className="text-xl font-black mb-1">Controle de Estoque da Casa</h2>
        <p className="text-xs text-slate-300 leading-relaxed">
          Dê baixa ao consumir produtos. Quando atingir o estoque mínimo, adicione à sua lista de compras com um toque.
        </p>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        <button
          onClick={() => setActiveFilter(activeFilter === 'critical' ? 'all' : 'critical')}
          className={`p-3 rounded-2xl border text-center transition-all ${
            activeFilter === 'critical' ? 'bg-rose-50 border-rose-300 shadow-xs' : 'bg-white border-slate-200/80'
          }`}
        >
          <span className="text-lg font-black text-rose-600 block">{criticalCount}</span>
          <span className="text-[10px] font-bold text-slate-500 uppercase">Críticos</span>
        </button>

        <button
          onClick={() => setActiveFilter(activeFilter === 'warning' ? 'all' : 'warning')}
          className={`p-3 rounded-2xl border text-center transition-all ${
            activeFilter === 'warning' ? 'bg-amber-50 border-amber-300 shadow-xs' : 'bg-white border-slate-200/80'
          }`}
        >
          <span className="text-lg font-black text-amber-600 block">{warningCount}</span>
          <span className="text-[10px] font-bold text-slate-500 uppercase">Atenção</span>
        </button>

        <button
          onClick={() => setActiveFilter(activeFilter === 'ok' ? 'all' : 'ok')}
          className={`p-3 rounded-2xl border text-center transition-all ${
            activeFilter === 'ok' ? 'bg-emerald-50 border-emerald-300 shadow-xs' : 'bg-white border-slate-200/80'
          }`}
        >
          <span className="text-lg font-black text-emerald-600 block">{okCount}</span>
          <span className="text-[10px] font-bold text-slate-500 uppercase">Normais</span>
        </button>
      </div>

      {/* Search & Category Filter */}
      <div className="space-y-2 mb-4">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={17} />
          <input 
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar produto na despensa..."
            className={`w-full bg-white border border-slate-200/80 rounded-2xl py-2.5 pl-10 pr-4 text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 ${themeColor.ring} shadow-xs text-slate-800`}
          />
        </div>

        {/* Categories Bar */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {['Todas', ...PANTRY_CATEGORIES].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-[11px] font-bold whitespace-nowrap transition-all ${
                selectedCategory === cat 
                  ? `${themeColor.bg} text-white` 
                  : 'bg-white border border-slate-200/70 text-slate-600 hover:bg-slate-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Add New Product Button */}
      <button
        onClick={handleOpenAdd}
        className={`w-full py-3.5 ${themeColor.bg} text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-2 shadow-xs hover:brightness-105 active:scale-98 transition-all mb-4`}
      >
        <Plus size={16} strokeWidth={3} />
        <span>Cadastrar Produto na Despensa</span>
      </button>

      {/* Product List */}
      <div className="space-y-2.5">
        <AnimatePresence>
          {filteredItems.length > 0 ? (
            filteredItems.map((item) => {
              const isCritical = (item.quantity ?? 0) <= (item.minQuantity ?? 1);
              const isWarning = (item.quantity ?? 0) === (item.minQuantity ?? 1) + 1;

              return (
                <motion.div
                  layout
                  key={item.id}
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="bg-white p-4 rounded-3xl shadow-xs border border-slate-200/70 flex items-center justify-between gap-3 hover:shadow-xs transition-all"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className={`text-[10px] font-black uppercase px-2 py-0.2 rounded-md ${
                        isCritical ? 'bg-rose-100 text-rose-700' :
                        isWarning ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'
                      }`}>
                        {isCritical ? 'Repor' : isWarning ? 'Baixo' : 'OK'}
                      </span>
                      <span className="text-[10px] text-slate-400 font-semibold">{item.category}</span>
                    </div>

                    <h4 className="text-sm font-extrabold text-slate-900 truncate">{item.name}</h4>
                    <p className="text-xs text-slate-400">
                      {item.brand ? `${item.brand} • ` : ''}Mínimo: {item.minQuantity} {item.unit}
                    </p>
                  </div>

                  {/* Stepper + Actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    {/* Stepper */}
                    <div className="flex items-center bg-slate-100 rounded-xl p-1 gap-1">
                      <button
                        onClick={() => handleDecrementStock(item)}
                        className="w-7 h-7 flex items-center justify-center text-slate-600 hover:text-slate-900 active:scale-75 transition-transform"
                        title="Consumir / Dar baixa"
                      >
                        <Minus size={14} strokeWidth={2.5} />
                      </button>
                      <span className="text-xs font-black min-w-8 text-center text-slate-900">
                        {item.quantity} {item.unit}
                      </span>
                      <button
                        onClick={() => handleIncrementStock(item)}
                        className="w-7 h-7 flex items-center justify-center text-slate-600 hover:text-slate-900 active:scale-75 transition-transform"
                        title="Repor estoque"
                      >
                        <Plus size={14} strokeWidth={2.5} />
                      </button>
                    </div>

                    {/* Quick Add to List if Critical */}
                    {isCritical && (
                      <button
                        onClick={() => {
                          setAlertProduct(item);
                          setAlertBuyQuantity(item.restockBuyQuantity || 2);
                          if (lists.length > 0) {
                            setSelectedListIdForAlert(lists[0].id);
                          }
                        }}
                        className={`p-2 rounded-xl ${themeColor.light} ${themeColor.text} hover:opacity-80 transition-opacity`}
                        title="Adicionar à lista de compras"
                      >
                        <ShoppingCart size={16} />
                      </button>
                    )}

                    <button
                      onClick={() => handleOpenEdit(item)}
                      className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl transition-all"
                      title="Editar"
                    >
                      <Edit3 size={15} />
                    </button>
                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      className="p-2 text-rose-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all"
                      title="Excluir"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </motion.div>
              );
            })
          ) : (
            <div className="text-center py-12 text-slate-400">
              <Package size={32} className="mx-auto mb-2 text-slate-300" />
              <p className="text-xs font-bold text-slate-600">Nenhum produto cadastrado na despensa.</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Cadastre itens da sua casa para não esquecer de repor.</p>
            </div>
          )}
        </AnimatePresence>
      </div>

      {/* Add / Edit Form Modal */}
      <AnimatePresence>
        {isFormOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 w-full max-w-md shadow-2xl border border-slate-100 max-h-[85vh] overflow-y-auto"
            >
              <h3 className="text-lg font-extrabold text-slate-900 mb-4">
                {editingItem ? 'Editar Produto na Despensa' : 'Novo Produto na Despensa'}
              </h3>
              <form onSubmit={handleSaveForm} className="space-y-3.5">
                <div>
                  <label className="text-xs font-bold text-slate-600 block mb-1">Nome do Produto</label>
                  <input 
                    type="text"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="Ex: Arroz, Leite, Café..."
                    className={`w-full h-11 px-3.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-medium focus:outline-none focus:ring-2 ${themeColor.ring}`}
                    autoFocus
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-600 block mb-1">Marca (opcional)</label>
                    <input 
                      type="text"
                      value={formBrand}
                      onChange={(e) => setFormBrand(e.target.value)}
                      placeholder="Ex: Camil, Tio João"
                      className="w-full h-11 px-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-600 block mb-1">Categoria</label>
                    <select 
                      value={formCategory}
                      onChange={(e) => setFormCategory(e.target.value)}
                      className="w-full h-11 px-3 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    >
                      {PANTRY_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-600 block mb-1">Qtd Atual</label>
                    <input 
                      type="text"
                      inputMode="decimal"
                      value={formQuantity}
                      onChange={(e) => setFormQuantity(e.target.value)}
                      className="w-full h-11 px-3.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-600 block mb-1">Unidade</label>
                    <select 
                      value={formUnit}
                      onChange={(e) => setFormUnit(e.target.value)}
                      className="w-full h-11 px-3 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    >
                      {PANTRY_UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-600 block mb-1">Estoque Mínimo</label>
                    <input 
                      type="text"
                      inputMode="decimal"
                      value={formMinQuantity}
                      onChange={(e) => setFormMinQuantity(e.target.value)}
                      className="w-full h-11 px-3.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-600 block mb-1">Qtd Sugerida Compra</label>
                    <input 
                      type="text"
                      inputMode="decimal"
                      value={formRestockBuyQuantity}
                      onChange={(e) => setFormRestockBuyQuantity(e.target.value)}
                      className="w-full h-11 px-3.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-bold"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-600 block mb-1">Validade (opcional)</label>
                  <input 
                    type="date"
                    value={formExpiryDate}
                    onChange={(e) => setFormExpiryDate(e.target.value)}
                    className="w-full h-11 px-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button 
                    type="button"
                    onClick={() => setIsFormOpen(false)}
                    className="flex-1 h-11 rounded-xl bg-slate-100 text-slate-600 font-bold text-xs"
                  >
                    Cancelar
                  </button>
                  <button 
                    type="submit"
                    className={`flex-1 h-11 rounded-xl ${themeColor.bg} text-white font-bold text-xs shadow-xs`}
                  >
                    Salvar
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Replenishment Alert to Grocery List Modal */}
      <AnimatePresence>
        {alertProduct && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl border border-slate-100"
            >
              <div className="flex items-center gap-3 mb-3 text-amber-600">
                <AlertTriangle size={24} />
                <h3 className="text-base font-extrabold text-slate-900">Hora de Repor!</h3>
              </div>

              <p className="text-xs text-slate-600 mb-4 leading-relaxed">
                O produto <strong>{alertProduct.name}</strong> atingiu o estoque mínimo ({alertProduct.quantity} {alertProduct.unit}). Deseja adicioná-lo à sua lista de compras?
              </p>

              <div className="space-y-3 mb-5">
                <div>
                  <label className="text-[11px] font-bold text-slate-500 block mb-1">Qual lista?</label>
                  <select
                    value={selectedListIdForAlert}
                    onChange={(e) => setSelectedListIdForAlert(e.target.value)}
                    className="w-full h-11 px-3 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                  >
                    {lists.map(l => <option key={l.id} value={l.id}>{l.name} ({l.status})</option>)}
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-500 block mb-1">Quantidade para comprar:</label>
                  <input
                    type="number"
                    min="1"
                    value={alertBuyQuantity}
                    onChange={(e) => setAlertBuyQuantity(parseInt(e.target.value, 10) || 1)}
                    className="w-full h-11 px-3.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-bold"
                  />
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setAlertProduct(null)}
                  className="flex-1 h-11 rounded-2xl bg-slate-100 text-slate-600 font-bold text-xs"
                >
                  Agora Não
                </button>
                <button
                  onClick={handleConfirmAddToList}
                  className={`flex-1 h-11 rounded-2xl ${themeColor.bg} text-white font-bold text-xs shadow-xs`}
                >
                  Adicionar à Lista
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
