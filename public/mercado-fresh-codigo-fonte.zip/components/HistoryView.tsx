'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Eye, 
  Copy, 
  Trash2, 
  Share2, 
  Receipt, 
  Calendar 
} from 'lucide-react';
import { GroceryList, Currency, ThemeColor } from '../lib/types';
import { 
  safeNumber, 
  safeFormatMoney, 
  parseItemAmount, 
  calculateItemPrice, 
  calculateItemSubtotal 
} from '../lib/utils';

interface HistoryViewProps {
  lists: GroceryList[];
  onDuplicateList: (list: GroceryList, newName: string) => void;
  onDeleteList: (id: string) => void;
  onShareList: (list: GroceryList) => void;
  currency: Currency;
  themeColor: ThemeColor;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  lists,
  onDuplicateList,
  onDeleteList,
  onShareList,
  currency,
  themeColor
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedReceipt, setSelectedReceipt] = useState<GroceryList | null>(null);

  const completedLists = lists.filter(l => l && l.status === 'Concluído');

  const filteredHistory = completedLists.filter(p => 
    p && (p.name || '').toLowerCase().includes((searchQuery || '').toLowerCase())
  );

  const calculateReceiptTotals = (list: GroceryList) => {
    let subtotal = 0;
    let totalDiscount = 0;

    (list.items || []).filter(Boolean).forEach(item => {
      const amount = parseItemAmount(item);
      const regularPrice = safeNumber(item.price, 0) * amount;
      const actualSubtotal = calculateItemSubtotal(item);
      
      subtotal += regularPrice;
      if (regularPrice > actualSubtotal) {
        totalDiscount += (regularPrice - actualSubtotal);
      }
    });

    const finalTotal = list.totalAmount !== undefined ? list.totalAmount : Math.max(0, subtotal - totalDiscount);
    return { subtotal, totalDiscount, total: finalTotal };
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="pt-20 px-4 max-w-2xl mx-auto pb-32"
    >
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900">Histórico de Compras</h2>
          <p className="text-xs text-slate-400">Suas compras anteriores salvas no dispositivo</p>
        </div>
        <span className={`text-[11px] font-bold px-3 py-1 rounded-full ${themeColor.light} ${themeColor.text}`}>
          {completedLists.length} {completedLists.length === 1 ? 'compra' : 'compras'}
        </span>
      </div>

      {/* Search */}
      <div className="relative mb-5">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
        <input 
          type="text" 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Buscar no histórico..." 
          className={`w-full bg-white border border-slate-200/80 rounded-2xl py-3 pl-11 pr-4 text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 ${themeColor.ring} shadow-xs text-slate-800`}
        />
      </div>

      {/* History List */}
      <div className="space-y-4">
        {filteredHistory.length > 0 ? (
          filteredHistory.map((trip) => {
            const itemCount = (trip.items || []).length;
            const tripTotal = trip.totalAmount !== undefined 
              ? trip.totalAmount 
              : (trip.items || []).reduce((acc, curr) => acc + calculateItemSubtotal(curr), 0);

            return (
              <div key={trip.id} className="bg-white rounded-3xl p-5 shadow-xs border border-slate-200/70 hover:shadow-md transition-all">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-1.5 text-slate-400 text-[11px] font-bold mb-1">
                      <Calendar size={13} />
                      <span>{trip.completedAt || 'Data não registrada'}</span>
                    </div>
                    <h3 className="text-base font-black text-slate-900">{trip.name}</h3>
                    <p className="text-xs text-slate-500 font-medium">
                      {itemCount} {itemCount === 1 ? 'item comprado' : 'itens comprados'}
                    </p>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Pago</span>
                    <span className={`text-lg font-black ${themeColor.text}`}>
                      {currency.symbol} {safeFormatMoney(tripTotal)}
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2 pt-3 border-t border-slate-100">
                  <button
                    onClick={() => setSelectedReceipt(trip)}
                    className={`flex-1 h-10 ${themeColor.bg} text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-xs hover:brightness-105 active:scale-98 transition-all`}
                  >
                    <Eye size={15} /> Ver Cupom
                  </button>
                  <button
                    onClick={() => onDuplicateList(trip, `${trip.name} (Repetir)`)}
                    className="flex-1 h-10 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors active:scale-98"
                  >
                    <Copy size={15} /> Repetir Lista
                  </button>
                  <button
                    onClick={() => onShareList(trip)}
                    className="w-10 h-10 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl flex items-center justify-center transition-colors active:scale-98"
                    title="Exportar"
                  >
                    <Share2 size={15} />
                  </button>
                  <button
                    onClick={() => onDeleteList(trip.id)}
                    className="w-10 h-10 bg-rose-50 hover:bg-rose-100 text-rose-500 rounded-xl flex items-center justify-center transition-colors active:scale-98"
                    title="Excluir do histórico"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-center py-16 text-slate-400">
            <div className="bg-slate-100 w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-3">
              <Receipt size={28} />
            </div>
            <p className="text-sm font-bold text-slate-700">Nenhuma compra finalizada</p>
            <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
              Ao concluir uma lista de compras pelo botão &quot;Finalizar Compra&quot;, o comprovante detalhado aparecerá aqui.
            </p>
          </div>
        )}
      </div>

      {/* Detailed Receipt Modal */}
      <AnimatePresence>
        {selectedReceipt && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 w-full max-w-md shadow-2xl border border-slate-100 max-h-[85vh] overflow-y-auto"
            >
              <div className="text-center border-b border-dashed border-slate-200 pb-3 mb-4">
                <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400">Cupom de Compra</span>
                <h4 className="font-black text-lg text-slate-900 mt-0.5">{selectedReceipt.name}</h4>
                <p className="text-xs text-slate-500 mt-0.5 font-medium">{selectedReceipt.completedAt || 'Data não registrada'}</p>
              </div>

              {/* Items List */}
              <div className="space-y-2.5 mb-4 text-xs">
                {(selectedReceipt.items || []).filter(Boolean).map((item, idx) => {
                  const amount = parseItemAmount(item);
                  const subtotal = calculateItemSubtotal(item);
                  const unitPrice = calculateItemPrice(item);
                  const isWholesale = item.minWholesaleQty && amount >= item.minWholesaleQty && item.wholesalePrice;

                  return (
                    <div key={idx} className="flex items-start justify-between border-b border-slate-100 pb-2">
                      <div className="flex-1 pr-2">
                        <p className="font-bold text-slate-800">{item.name}</p>
                        <p className="text-[11px] text-slate-400">
                          {item.weight ? `${item.weight}kg` : `${item.quantity}un`} x {currency.symbol} {safeFormatMoney(unitPrice)}
                          {isWholesale && <span className="ml-1 text-emerald-600 font-bold">(Desc. Atacado)</span>}
                        </p>
                      </div>
                      <span className="font-black text-slate-900 shrink-0">
                        {currency.symbol} {safeFormatMoney(subtotal)}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Receipt Totals Summary */}
              {(() => {
                const totals = calculateReceiptTotals(selectedReceipt);
                return (
                  <div className="pt-3 border-t-2 border-dashed border-slate-200 space-y-1.5 text-xs mb-5">
                    <div className="flex justify-between text-slate-500">
                      <span>Subtotal bruto</span>
                      <span>{currency.symbol} {safeFormatMoney(totals.subtotal)}</span>
                    </div>
                    {totals.totalDiscount > 0 && (
                      <div className="flex justify-between font-bold text-emerald-600">
                        <span>Descontos obtidos</span>
                        <span>- {currency.symbol} {safeFormatMoney(totals.totalDiscount)}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-base font-black text-slate-900 pt-2 border-t border-slate-100">
                      <span>Total Pago</span>
                      <span>{currency.symbol} {safeFormatMoney(totals.total)}</span>
                    </div>
                  </div>
                );
              })()}

              <div className="flex gap-2">
                <button
                  onClick={() => setSelectedReceipt(null)}
                  className="flex-1 h-11 rounded-2xl bg-slate-100 text-slate-600 font-bold text-xs hover:bg-slate-200 transition-colors"
                >
                  Fechar
                </button>
                <button
                  onClick={() => {
                    onShareList(selectedReceipt);
                    setSelectedReceipt(null);
                  }}
                  className={`flex-1 h-11 rounded-2xl ${themeColor.bg} text-white font-bold text-xs shadow-xs hover:brightness-105 transition-all flex items-center justify-center gap-1.5`}
                >
                  <Share2 size={14} /> Compartilhar
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
